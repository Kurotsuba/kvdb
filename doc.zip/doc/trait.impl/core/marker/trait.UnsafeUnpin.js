(function() {
    var implementors = Object.fromEntries([["kvdb",[["impl UnsafeUnpin for <a class=\"struct\" href=\"kvdb/struct.VecDB.html\" title=\"struct kvdb::VecDB\">VecDB</a>",1,["kvdb::db::VecDB"]]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":57,"fragment_lengths":[148]}