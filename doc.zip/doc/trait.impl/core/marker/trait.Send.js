(function() {
    var implementors = Object.fromEntries([["kvdb",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.91.0/core/marker/trait.Send.html\" title=\"trait core::marker::Send\">Send</a> for <a class=\"struct\" href=\"kvdb/struct.VecDB.html\" title=\"struct kvdb::VecDB\">VecDB</a>",1,["kvdb::db::VecDB"]]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":57,"fragment_lengths":[269]}